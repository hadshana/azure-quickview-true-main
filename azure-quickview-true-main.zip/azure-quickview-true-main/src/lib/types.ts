export interface AzureSubscription {
  id: string
  name: string
  displayName: string
}

export interface VirtualMachine {
  id: string
  name: string
  resourceGroup: string
  status: 'Running' | 'Stopped' | 'Deallocated'
  tags: Record<string, string>
  lastModified: string
  location: string
}

export interface UnattachedResource {
  id: string
  name: string
  type: 'Disk' | 'NIC' | 'PublicIP' | 'NSG'
  resourceGroup: string
  lastModified: string
  size?: string
  location: string
}

export interface AdvisorRecommendation {
  id: string
  vmName: string
  category: 'Cost' | 'Security' | 'Performance' | 'Reliability' | 'Operational Excellence'
  severity: 'Critical' | 'High' | 'Medium' | 'Low'
  title: string
  description: string
  impactedResource: string
  resourceGroup: string
}

export interface RunbookJob {
  id: string
  runbookName: string
  schedule: string
  lastRunTime: string
  status: 'Running' | 'Completed' | 'Failed'
  duration?: string
  nextRunTime: string
}

export interface PatchCompliance {
  totalHosts: number
  compliantHosts: number
  nonCompliantHosts: Array<{
    name: string
    resourceGroup: string
    missingPatches: number
    criticalPatches: number
    lastAssessed: string
  }>
  compliancePercentage: number
}

export interface CostDataPoint {
  date: string
  cost: number
  forecastCost?: number
}

export interface CostDriver {
  resourceName: string
  resourceType: string
  resourceGroup: string
  cost: number
  trend: 'up' | 'down' | 'stable'
  percentageOfTotal: number
}

export interface DashboardData {
  subscriptionId: string
  summary: {
    totalVMs: number
    untaggedVMs: number
    runningVMs: number
    stoppedVMs: number
  }
  virtualMachines: VirtualMachine[]
  unattachedResources: UnattachedResource[]
  advisorRecommendations: AdvisorRecommendation[]
  runbookJobs: RunbookJob[]
  patchCompliance: PatchCompliance
  costAnalysis: {
    history: CostDataPoint[]
    topDrivers: CostDriver[]
    totalCost: number
    previousMonthCost: number
    trend: 'up' | 'down' | 'stable'
  }
}

export type DashboardFilter =
  | 'Untagged Virtual Machines'
  | 'Unattached Resources (VM, Disk, NIC, etc.)'
  | 'Azure Advisor Recommendations'
  | 'Patch Management Summary'
  | 'Runbook Schedule Overview'
  | 'Cost Analysis (last 3 months)'
  | 'Top 10 Cost Drivers'
