import type {
  AzureSubscription,
  DashboardData,
  VirtualMachine,
  UnattachedResource,
  AdvisorRecommendation,
  RunbookJob,
  CostDataPoint,
  CostDriver,
} from './types'

export const mockSubscriptions: AzureSubscription[] = [
  {
    id: 'sub-1a2b3c4d',
    name: 'Production',
    displayName: 'Production Environment',
  },
  {
    id: 'sub-5e6f7g8h',
    name: 'Development',
    displayName: 'Development & Testing',
  },
  {
    id: 'sub-9i0j1k2l',
    name: 'Staging',
    displayName: 'Staging Environment',
  },
]

const generateVMs = (subscriptionId: string): VirtualMachine[] => {
  const baseVMs: VirtualMachine[] = [
    {
      id: `${subscriptionId}/vm-web-01`,
      name: 'vm-web-01',
      resourceGroup: 'rg-webapp-prod',
      status: 'Running',
      tags: { Environment: 'Production', Owner: 'WebTeam' },
      lastModified: '2024-01-15T10:30:00Z',
      location: 'eastus',
    },
    {
      id: `${subscriptionId}/vm-web-02`,
      name: 'vm-web-02',
      resourceGroup: 'rg-webapp-prod',
      status: 'Running',
      tags: {},
      lastModified: '2024-01-10T14:20:00Z',
      location: 'eastus',
    },
    {
      id: `${subscriptionId}/vm-db-01`,
      name: 'vm-db-01',
      resourceGroup: 'rg-database-prod',
      status: 'Running',
      tags: { Environment: 'Production', CostCenter: 'CC-1234' },
      lastModified: '2024-01-20T08:45:00Z',
      location: 'westus',
    },
    {
      id: `${subscriptionId}/vm-app-test`,
      name: 'vm-app-test',
      resourceGroup: 'rg-testing',
      status: 'Stopped',
      tags: {},
      lastModified: '2023-12-28T16:10:00Z',
      location: 'centralus',
    },
    {
      id: `${subscriptionId}/vm-analytics`,
      name: 'vm-analytics',
      resourceGroup: 'rg-data-analytics',
      status: 'Running',
      tags: { Department: 'Analytics' },
      lastModified: '2024-01-18T11:00:00Z',
      location: 'eastus2',
    },
    {
      id: `${subscriptionId}/vm-batch-worker`,
      name: 'vm-batch-worker',
      resourceGroup: 'rg-batch-processing',
      status: 'Deallocated',
      tags: {},
      lastModified: '2023-12-15T09:30:00Z',
      location: 'northeurope',
    },
    {
      id: `${subscriptionId}/vm-legacy-app`,
      name: 'vm-legacy-app',
      resourceGroup: 'rg-legacy',
      status: 'Running',
      tags: {},
      lastModified: '2023-11-05T07:15:00Z',
      location: 'westeurope',
    },
  ]

  return baseVMs
}

const generateUnattachedResources = (subscriptionId: string): UnattachedResource[] => {
  return [
    {
      id: `${subscriptionId}/disk-orphan-01`,
      name: 'disk-orphan-01',
      type: 'Disk',
      resourceGroup: 'rg-webapp-prod',
      lastModified: '2023-11-20T14:30:00Z',
      size: '128 GB',
      location: 'eastus',
    },
    {
      id: `${subscriptionId}/nic-unused-05`,
      name: 'nic-unused-05',
      type: 'NIC',
      resourceGroup: 'rg-testing',
      lastModified: '2023-12-01T10:00:00Z',
      location: 'centralus',
    },
    {
      id: `${subscriptionId}/pip-old-lb`,
      name: 'pip-old-lb',
      type: 'PublicIP',
      resourceGroup: 'rg-networking',
      lastModified: '2023-10-15T16:45:00Z',
      location: 'eastus',
    },
    {
      id: `${subscriptionId}/disk-snapshot-temp`,
      name: 'disk-snapshot-temp',
      type: 'Disk',
      resourceGroup: 'rg-database-prod',
      lastModified: '2023-12-10T08:20:00Z',
      size: '512 GB',
      location: 'westus',
    },
    {
      id: `${subscriptionId}/nsg-old-subnet`,
      name: 'nsg-old-subnet',
      type: 'NSG',
      resourceGroup: 'rg-networking',
      lastModified: '2023-09-22T12:30:00Z',
      location: 'eastus2',
    },
  ]
}

const generateAdvisorRecommendations = (subscriptionId: string): AdvisorRecommendation[] => {
  return [
    {
      id: `${subscriptionId}/advisor-001`,
      vmName: 'vm-web-02',
      category: 'Security',
      severity: 'Critical',
      title: 'Enable Azure Disk Encryption',
      description: 'Virtual machine disks are not encrypted. Enable encryption to protect data at rest.',
      impactedResource: 'vm-web-02',
      resourceGroup: 'rg-webapp-prod',
    },
    {
      id: `${subscriptionId}/advisor-002`,
      vmName: 'vm-db-01',
      category: 'Cost',
      severity: 'High',
      title: 'Right-size underutilized virtual machine',
      description: 'CPU utilization has been below 10% for the last 7 days. Consider downsizing.',
      impactedResource: 'vm-db-01',
      resourceGroup: 'rg-database-prod',
    },
    {
      id: `${subscriptionId}/advisor-003`,
      vmName: 'vm-analytics',
      category: 'Performance',
      severity: 'Medium',
      title: 'Enable Accelerated Networking',
      description: 'Improve network throughput and reduce latency by enabling accelerated networking.',
      impactedResource: 'vm-analytics',
      resourceGroup: 'rg-data-analytics',
    },
    {
      id: `${subscriptionId}/advisor-004`,
      vmName: 'vm-legacy-app',
      category: 'Security',
      severity: 'High',
      title: 'Update to supported OS version',
      description: 'This VM is running an OS version that is no longer supported. Upgrade to maintain security.',
      impactedResource: 'vm-legacy-app',
      resourceGroup: 'rg-legacy',
    },
    {
      id: `${subscriptionId}/advisor-005`,
      vmName: 'vm-web-01',
      category: 'Reliability',
      severity: 'Medium',
      title: 'Configure backup for virtual machine',
      description: 'No backup policy is configured. Enable Azure Backup for disaster recovery.',
      impactedResource: 'vm-web-01',
      resourceGroup: 'rg-webapp-prod',
    },
    {
      id: `${subscriptionId}/advisor-006`,
      vmName: 'vm-batch-worker',
      category: 'Cost',
      severity: 'Low',
      title: 'Delete or start deallocated VM',
      description: 'This VM has been deallocated for over 30 days. Consider deleting if no longer needed.',
      impactedResource: 'vm-batch-worker',
      resourceGroup: 'rg-batch-processing',
    },
  ]
}

const generateRunbookJobs = (subscriptionId: string): RunbookJob[] => {
  return [
    {
      id: `${subscriptionId}/runbook-001`,
      runbookName: 'Start-VMs-Business-Hours',
      schedule: 'Daily at 7:00 AM UTC',
      lastRunTime: '2024-01-22T07:00:00Z',
      status: 'Completed',
      duration: '2m 15s',
      nextRunTime: '2024-01-23T07:00:00Z',
    },
    {
      id: `${subscriptionId}/runbook-002`,
      runbookName: 'Stop-VMs-After-Hours',
      schedule: 'Daily at 7:00 PM UTC',
      lastRunTime: '2024-01-22T19:00:00Z',
      status: 'Completed',
      duration: '1m 45s',
      nextRunTime: '2024-01-23T19:00:00Z',
    },
    {
      id: `${subscriptionId}/runbook-003`,
      runbookName: 'Backup-Configuration',
      schedule: 'Weekly on Sunday at 2:00 AM UTC',
      lastRunTime: '2024-01-21T02:00:00Z',
      status: 'Failed',
      duration: '5m 10s',
      nextRunTime: '2024-01-28T02:00:00Z',
    },
    {
      id: `${subscriptionId}/runbook-004`,
      runbookName: 'Cleanup-Old-Snapshots',
      schedule: 'Monthly on 1st at 3:00 AM UTC',
      lastRunTime: '2024-01-22T03:00:00Z',
      status: 'Running',
      nextRunTime: '2024-02-01T03:00:00Z',
    },
    {
      id: `${subscriptionId}/runbook-005`,
      runbookName: 'Update-NSG-Rules',
      schedule: 'Daily at 1:00 AM UTC',
      lastRunTime: '2024-01-22T01:00:00Z',
      status: 'Completed',
      duration: '45s',
      nextRunTime: '2024-01-23T01:00:00Z',
    },
  ]
}

const generateCostHistory = (): CostDataPoint[] => {
  const today = new Date()
  const data: CostDataPoint[] = []
  
  for (let i = 89; i >= 0; i--) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)
    
    const baselineCost = 8500
    const trend = Math.sin((i / 90) * Math.PI * 2) * 1500
    const randomVariation = (Math.random() - 0.5) * 800
    const cost = baselineCost + trend + randomVariation
    
    data.push({
      date: date.toISOString().split('T')[0],
      cost: Math.round(cost * 100) / 100,
    })
  }
  
  return data
}

const generateTopCostDrivers = (subscriptionId: string): CostDriver[] => {
  return [
    {
      resourceName: 'vm-db-01',
      resourceType: 'Virtual Machine',
      resourceGroup: 'rg-database-prod',
      cost: 3245.67,
      trend: 'up',
      percentageOfTotal: 35.2,
    },
    {
      resourceName: 'vm-analytics',
      resourceType: 'Virtual Machine',
      resourceGroup: 'rg-data-analytics',
      cost: 2187.43,
      trend: 'stable',
      percentageOfTotal: 23.7,
    },
    {
      resourceName: 'storage-prod-logs',
      resourceType: 'Storage Account',
      resourceGroup: 'rg-storage',
      cost: 1456.89,
      trend: 'up',
      percentageOfTotal: 15.8,
    },
    {
      resourceName: 'vm-web-01',
      resourceType: 'Virtual Machine',
      resourceGroup: 'rg-webapp-prod',
      cost: 892.34,
      trend: 'down',
      percentageOfTotal: 9.7,
    },
    {
      resourceName: 'cosmos-db-prod',
      resourceType: 'Cosmos DB',
      resourceGroup: 'rg-database-prod',
      cost: 634.21,
      trend: 'stable',
      percentageOfTotal: 6.9,
    },
    {
      resourceName: 'app-gateway-prod',
      resourceType: 'Application Gateway',
      resourceGroup: 'rg-networking',
      cost: 287.56,
      trend: 'stable',
      percentageOfTotal: 3.1,
    },
    {
      resourceName: 'vm-legacy-app',
      resourceType: 'Virtual Machine',
      resourceGroup: 'rg-legacy',
      cost: 198.45,
      trend: 'down',
      percentageOfTotal: 2.2,
    },
    {
      resourceName: 'sql-server-prod',
      resourceType: 'SQL Database',
      resourceGroup: 'rg-database-prod',
      cost: 156.78,
      trend: 'up',
      percentageOfTotal: 1.7,
    },
    {
      resourceName: 'vnet-hub-prod',
      resourceType: 'Virtual Network',
      resourceGroup: 'rg-networking',
      cost: 89.23,
      trend: 'stable',
      percentageOfTotal: 1.0,
    },
    {
      resourceName: 'keyvault-prod',
      resourceType: 'Key Vault',
      resourceGroup: 'rg-security',
      cost: 67.44,
      trend: 'stable',
      percentageOfTotal: 0.7,
    },
  ]
}

export const generateMockDashboardData = (subscriptionId: string): DashboardData => {
  const vms = generateVMs(subscriptionId)
  const untaggedVMs = vms.filter(vm => Object.keys(vm.tags).length === 0)
  const runningVMs = vms.filter(vm => vm.status === 'Running')
  const stoppedVMs = vms.filter(vm => vm.status === 'Stopped' || vm.status === 'Deallocated')

  const costHistory = generateCostHistory()
  const totalCost = costHistory[costHistory.length - 1].cost
  const previousMonthCost = costHistory[costHistory.length - 31]?.cost || totalCost

  return {
    subscriptionId,
    summary: {
      totalVMs: vms.length,
      untaggedVMs: untaggedVMs.length,
      runningVMs: runningVMs.length,
      stoppedVMs: stoppedVMs.length,
    },
    virtualMachines: vms,
    unattachedResources: generateUnattachedResources(subscriptionId),
    advisorRecommendations: generateAdvisorRecommendations(subscriptionId),
    runbookJobs: generateRunbookJobs(subscriptionId),
    patchCompliance: {
      totalHosts: vms.length,
      compliantHosts: 4,
      compliancePercentage: 57.1,
      nonCompliantHosts: [
        {
          name: 'vm-web-02',
          resourceGroup: 'rg-webapp-prod',
          missingPatches: 12,
          criticalPatches: 3,
          lastAssessed: '2024-01-20T10:00:00Z',
        },
        {
          name: 'vm-legacy-app',
          resourceGroup: 'rg-legacy',
          missingPatches: 28,
          criticalPatches: 8,
          lastAssessed: '2024-01-19T10:00:00Z',
        },
        {
          name: 'vm-batch-worker',
          resourceGroup: 'rg-batch-processing',
          missingPatches: 15,
          criticalPatches: 2,
          lastAssessed: '2024-01-18T10:00:00Z',
        },
      ],
    },
    costAnalysis: {
      history: costHistory,
      topDrivers: generateTopCostDrivers(subscriptionId),
      totalCost,
      previousMonthCost,
      trend: totalCost > previousMonthCost ? 'up' : totalCost < previousMonthCost ? 'down' : 'stable',
    },
  }
}

export const mockApi = {
  getSubscriptions: async (): Promise<AzureSubscription[]> => {
    await new Promise(resolve => setTimeout(resolve, 300))
    return mockSubscriptions
  },

  getDashboardData: async (subscriptionId: string): Promise<DashboardData> => {
    await new Promise(resolve => setTimeout(resolve, 500))
    return generateMockDashboardData(subscriptionId)
  },
}
