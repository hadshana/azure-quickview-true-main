import { useState, useEffect } from 'react'
import { Toaster } from '@/components/ui/sonner'
import { DashboardHeader } from '@/components/DashboardHeader'
import { SummaryTiles } from '@/components/SummaryTiles'
import { ResourcesList } from '@/components/ResourcesList'
import { AdvisorRecommendations } from '@/components/AdvisorRecommendations'
import { RunbookSchedule } from '@/components/RunbookSchedule'
import { PatchManagement } from '@/components/PatchManagement'
import { CostAnalysis } from '@/components/CostAnalysis'
import { mockApi } from '@/lib/mockData'
import type { AzureSubscription, DashboardData, DashboardFilter } from '@/lib/types'
import { toast } from 'sonner'

function App() {
  const [subscriptions, setSubscriptions] = useState<AzureSubscription[]>([])
  const [selectedSubscription, setSelectedSubscription] = useState<string>('')
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null)
  const [selectedFilters, setSelectedFilters] = useState<DashboardFilter[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadSubscriptions = async () => {
      try {
        const subs = await mockApi.getSubscriptions()
        setSubscriptions(subs)
        if (subs.length > 0) {
          setSelectedSubscription(subs[0].id)
        }
      } catch (error) {
        toast.error('Failed to load subscriptions')
        console.error(error)
      }
    }
    loadSubscriptions()
  }, [])

  useEffect(() => {
    if (!selectedSubscription) return

    const loadDashboardData = async () => {
      setLoading(true)
      try {
        const data = await mockApi.getDashboardData(selectedSubscription)
        setDashboardData(data)
      } catch (error) {
        toast.error('Failed to load dashboard data')
        console.error(error)
      } finally {
        setLoading(false)
      }
    }
    loadDashboardData()
  }, [selectedSubscription])

  const handleGenerateReport = (format: 'pdf' | 'email') => {
    if (format === 'pdf') {
      toast.success('PDF report generated successfully', {
        description: 'Downloading Azure QuickView Monthly Summary...',
      })
      setTimeout(() => {
        const blob = new Blob(['Mock PDF content'], { type: 'application/pdf' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `azure-quickview-${new Date().toISOString().split('T')[0]}.pdf`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(url)
      }, 500)
    } else if (format === 'email') {
      const subject = encodeURIComponent('Azure QuickView Monthly Summary')
      const body = encodeURIComponent(
        `Please find attached the monthly Azure resource summary.\n\nGenerated on: ${new Date().toLocaleDateString()}`
      )
      window.location.href = `mailto:?subject=${subject}&body=${body}`
      toast.success('Opening email client', {
        description: 'Report will be attached automatically',
      })
    }
  }

  const shouldShowSection = (filterName: DashboardFilter): boolean => {
    if (selectedFilters.length === 0) return true
    return selectedFilters.includes(filterName)
  }

  if (loading || !dashboardData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader
        subscriptions={subscriptions}
        selectedSubscription={selectedSubscription}
        onSubscriptionChange={setSelectedSubscription}
        selectedFilters={selectedFilters}
        onFiltersChange={setSelectedFilters}
        onGenerateReport={handleGenerateReport}
      />

      <main className="container mx-auto px-4 py-8 space-y-8">
        {(selectedFilters.length === 0) && (
          <SummaryTiles
            totalVMs={dashboardData.summary.totalVMs}
            untaggedVMs={dashboardData.summary.untaggedVMs}
            runningVMs={dashboardData.summary.runningVMs}
            stoppedVMs={dashboardData.summary.stoppedVMs}
          />
        )}

        {(shouldShowSection('Untagged Virtual Machines') ||
          shouldShowSection('Unattached Resources (VM, Disk, NIC, etc.)')) && (
          <ResourcesList
            virtualMachines={dashboardData.virtualMachines}
            unattachedResources={dashboardData.unattachedResources}
          />
        )}

        {shouldShowSection('Azure Advisor Recommendations') && (
          <AdvisorRecommendations
            recommendations={dashboardData.advisorRecommendations}
          />
        )}

        {shouldShowSection('Runbook Schedule Overview') && (
          <RunbookSchedule jobs={dashboardData.runbookJobs} />
        )}

        {shouldShowSection('Patch Management Summary') && (
          <PatchManagement patchCompliance={dashboardData.patchCompliance} />
        )}

        {(shouldShowSection('Cost Analysis (last 3 months)') ||
          shouldShowSection('Top 10 Cost Drivers')) && (
          <CostAnalysis
            history={dashboardData.costAnalysis.history}
            topDrivers={dashboardData.costAnalysis.topDrivers}
            totalCost={dashboardData.costAnalysis.totalCost}
            previousMonthCost={dashboardData.costAnalysis.previousMonthCost}
            trend={dashboardData.costAnalysis.trend}
          />
        )}

        <div className="border-t pt-6">
          <div className="bg-muted/30 rounded-lg p-6">
            <h3 className="text-sm font-semibold mb-3">Azure Integration Setup</h3>
            <p className="text-sm text-muted-foreground mb-3">
              This dashboard currently uses mock data for demonstration. To connect to real Azure APIs:
            </p>
            <ol className="text-sm text-muted-foreground space-y-2 list-decimal list-inside">
              <li>
                Create an Azure Service Principal or configure Managed Identity with Reader
                access to your subscriptions
              </li>
              <li>
                Store credentials securely using Azure Key Vault or environment variables
              </li>
              <li>
                Replace mock API calls in <code className="bg-muted px-1.5 py-0.5 rounded text-xs">src/lib/mockData.ts</code> with
                Azure SDK calls
              </li>
              <li>
                Install required packages: <code className="bg-muted px-1.5 py-0.5 rounded text-xs">@azure/arm-compute</code>,{' '}
                <code className="bg-muted px-1.5 py-0.5 rounded text-xs">@azure/arm-advisor</code>,{' '}
                <code className="bg-muted px-1.5 py-0.5 rounded text-xs">@azure/arm-costmanagement</code>
              </li>
            </ol>
          </div>
        </div>
      </main>

      <Toaster position="top-right" />
    </div>
  )
}

export default App