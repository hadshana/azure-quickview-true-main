import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { ArrowSquareOut, Wrench, Warning } from '@phosphor-icons/react'
import type { PatchCompliance } from '@/lib/types'
import { generateAzurePortalUrl, formatDate, formatPercentage } from '@/lib/helpers'
import { toast } from 'sonner'

interface PatchManagementProps {
  patchCompliance: PatchCompliance
}

export function PatchManagement({ patchCompliance }: PatchManagementProps) {
  const handleOpenPortal = (hostName: string) => {
    const url = generateAzurePortalUrl(`/vm/${hostName}`)
    window.open(url, '_blank', 'noopener,noreferrer')
    toast.success(`Opening ${hostName} in Azure Portal`)
  }

  const handleRemediate = (hostName: string) => {
    toast.success(`Patch deployment scheduled for ${hostName}`, {
      description: 'Updates will be applied during next maintenance window',
    })
  }

  const isCompliant = patchCompliance.compliancePercentage >= 90
  const isWarning = patchCompliance.compliancePercentage >= 70 && patchCompliance.compliancePercentage < 90
  const isCritical = patchCompliance.compliancePercentage < 70

  return (
    <Card>
      <CardHeader>
        <CardTitle>Patch Management Summary</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                Compliance Status
              </p>
              <p className="text-3xl font-bold mt-1">
                {formatPercentage(patchCompliance.compliancePercentage)}
              </p>
              <p className="text-sm text-muted-foreground mt-1">
                {patchCompliance.compliantHosts} of {patchCompliance.totalHosts} hosts compliant
              </p>
            </div>
            <div>
              {isCritical && (
                <Badge variant="destructive" className="gap-1">
                  <Warning size={14} weight="fill" />
                  Critical
                </Badge>
              )}
              {isWarning && (
                <Badge className="gap-1 bg-warning text-warning-foreground">
                  <Warning size={14} weight="fill" />
                  Warning
                </Badge>
              )}
              {isCompliant && (
                <Badge className="gap-1 bg-success text-success-foreground">
                  Compliant
                </Badge>
              )}
            </div>
          </div>
          <Progress
            value={patchCompliance.compliancePercentage}
            className="h-2"
          />
        </div>

        {patchCompliance.nonCompliantHosts.length > 0 && (
          <div>
            <h3 className="text-sm font-semibold mb-3">Non-Compliant Hosts</h3>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Host Name</TableHead>
                    <TableHead>Resource Group</TableHead>
                    <TableHead>Missing Patches</TableHead>
                    <TableHead>Critical</TableHead>
                    <TableHead>Last Assessed</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {patchCompliance.nonCompliantHosts.map(host => (
                    <TableRow key={host.name} className={host.criticalPatches > 0 ? 'bg-destructive/5' : ''}>
                      <TableCell className="font-medium">{host.name}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {host.resourceGroup}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{host.missingPatches}</Badge>
                      </TableCell>
                      <TableCell>
                        {host.criticalPatches > 0 ? (
                          <Badge variant="destructive" className="gap-1">
                            <Warning size={14} weight="fill" />
                            {host.criticalPatches}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDate(host.lastAssessed)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex gap-2 justify-end">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleOpenPortal(host.name)}
                          >
                            <ArrowSquareOut size={16} className="mr-1" />
                            Portal
                          </Button>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => handleRemediate(host.name)}
                          >
                            <Wrench size={16} className="mr-1" />
                            Patch
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
