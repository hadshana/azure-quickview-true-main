import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArrowSquareOut, Wrench } from '@phosphor-icons/react'
import type { VirtualMachine, UnattachedResource } from '@/lib/types'
import { generateAzurePortalUrl, formatRelativeTime } from '@/lib/helpers'
import { toast } from 'sonner'

interface ResourcesListProps {
  virtualMachines: VirtualMachine[]
  unattachedResources: UnattachedResource[]
}

export function ResourcesList({ virtualMachines, unattachedResources }: ResourcesListProps) {
  const untaggedVMs = virtualMachines.filter(vm => Object.keys(vm.tags).length === 0)

  const handleOpenPortal = (resourceId: string, resourceName: string) => {
    const url = generateAzurePortalUrl(resourceId)
    window.open(url, '_blank', 'noopener,noreferrer')
    toast.success(`Opening ${resourceName} in Azure Portal`)
  }

  const handleRemediate = (resourceName: string, action: string) => {
    toast.success(`Remediation runbook triggered for ${resourceName}`, {
      description: `Action: ${action}`,
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Resource Management</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="untagged" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="untagged">
              Untagged VMs ({untaggedVMs.length})
            </TabsTrigger>
            <TabsTrigger value="unattached">
              Unattached Resources ({unattachedResources.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="untagged" className="mt-4">
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Resource Group</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Modified</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {untaggedVMs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                        No untagged VMs found. Great job!
                      </TableCell>
                    </TableRow>
                  ) : (
                    untaggedVMs.map(vm => (
                      <TableRow key={vm.id}>
                        <TableCell className="font-medium">{vm.name}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {vm.resourceGroup}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={vm.status === 'Running' ? 'default' : 'secondary'}
                            className={
                              vm.status === 'Running'
                                ? 'bg-success text-success-foreground'
                                : ''
                            }
                          >
                            {vm.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatRelativeTime(vm.lastModified)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex gap-2 justify-end">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenPortal(vm.id, vm.name)}
                            >
                              <ArrowSquareOut size={16} className="mr-1" />
                              Portal
                            </Button>
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() =>
                                handleRemediate(vm.name, 'Apply default tags')
                              }
                            >
                              <Wrench size={16} className="mr-1" />
                              Tag
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="unattached" className="mt-4">
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Resource Group</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Last Modified</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {unattachedResources.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                        No unattached resources found.
                      </TableCell>
                    </TableRow>
                  ) : (
                    unattachedResources.map(resource => (
                      <TableRow key={resource.id}>
                        <TableCell className="font-medium">{resource.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{resource.type}</Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {resource.resourceGroup}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {resource.size || '—'}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatRelativeTime(resource.lastModified)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex gap-2 justify-end">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() =>
                                handleOpenPortal(resource.id, resource.name)
                              }
                            >
                              <ArrowSquareOut size={16} className="mr-1" />
                              Portal
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() =>
                                handleRemediate(resource.name, 'Delete resource')
                              }
                            >
                              <Wrench size={16} className="mr-1" />
                              Delete
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
