import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowSquareOut, CheckCircle, XCircle, Spinner } from '@phosphor-icons/react'
import type { RunbookJob } from '@/lib/types'
import { generateAzurePortalUrl, formatDate } from '@/lib/helpers'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

interface RunbookScheduleProps {
  jobs: RunbookJob[]
}

const statusConfig = {
  Running: {
    icon: <Spinner size={16} className="animate-spin" />,
    className: 'bg-info text-info-foreground',
    label: 'Running',
  },
  Completed: {
    icon: <CheckCircle size={16} weight="fill" />,
    className: 'bg-success text-success-foreground',
    label: 'Completed',
  },
  Failed: {
    icon: <XCircle size={16} weight="fill" />,
    className: 'bg-destructive text-destructive-foreground',
    label: 'Failed',
  },
}

export function RunbookSchedule({ jobs }: RunbookScheduleProps) {
  const handleOpenPortal = (jobId: string, runbookName: string) => {
    const url = generateAzurePortalUrl(jobId)
    window.open(url, '_blank', 'noopener,noreferrer')
    toast.success(`Opening ${runbookName} in Azure Portal`)
  }

  const failedCount = jobs.filter(j => j.status === 'Failed').length
  const runningCount = jobs.filter(j => j.status === 'Running').length

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Runbook Schedule Overview</CardTitle>
          <div className="flex gap-2">
            {runningCount > 0 && (
              <Badge className="gap-1 bg-info text-info-foreground">
                <Spinner size={14} className="animate-spin" />
                {runningCount} Running
              </Badge>
            )}
            {failedCount > 0 && (
              <Badge variant="destructive" className="gap-1">
                <XCircle size={14} weight="fill" />
                {failedCount} Failed
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Runbook Name</TableHead>
                <TableHead>Schedule</TableHead>
                <TableHead>Last Run</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>Next Run</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {jobs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                    No scheduled runbooks found.
                  </TableCell>
                </TableRow>
              ) : (
                jobs.map(job => {
                  const config = statusConfig[job.status]
                  return (
                    <TableRow key={job.id} className={job.status === 'Failed' ? 'bg-destructive/5' : ''}>
                      <TableCell className="font-medium">{job.runbookName}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {job.schedule}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDate(job.lastRunTime)}
                      </TableCell>
                      <TableCell>
                        <Badge className={cn('gap-1', config.className)}>
                          {config.icon}
                          {config.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {job.duration || '—'}
                      </TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {formatDate(job.nextRunTime)}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleOpenPortal(job.id, job.runbookName)}
                        >
                          <ArrowSquareOut size={16} className="mr-1" />
                          Portal
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
