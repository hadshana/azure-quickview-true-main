import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowSquareOut, TrendUp, TrendDown, ArrowRight } from '@phosphor-icons/react'
import type { CostDataPoint, CostDriver } from '@/lib/types'
import { formatCurrency } from '@/lib/helpers'
import { toast } from 'sonner'
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'

interface CostAnalysisProps {
  history: CostDataPoint[]
  topDrivers: CostDriver[]
  totalCost: number
  previousMonthCost: number
  trend: 'up' | 'down' | 'stable'
}

export function CostAnalysis({
  history,
  topDrivers,
  totalCost,
  previousMonthCost,
  trend,
}: CostAnalysisProps) {
  const handleOpenPortal = (resourceName: string) => {
    toast.success(`Opening ${resourceName} in Azure Portal`)
  }

  const costChange = totalCost - previousMonthCost
  const costChangePercentage = ((costChange / previousMonthCost) * 100).toFixed(1)

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Cost Analysis (Last 3 Months)</CardTitle>
            <div className="text-right">
              <div className="text-2xl font-bold">{formatCurrency(totalCost)}</div>
              <div className="flex items-center gap-1 text-sm mt-1">
                {trend === 'up' && (
                  <>
                    <TrendUp size={16} className="text-destructive" />
                    <span className="text-destructive">
                      +{costChangePercentage}% from last month
                    </span>
                  </>
                )}
                {trend === 'down' && (
                  <>
                    <TrendDown size={16} className="text-success" />
                    <span className="text-success">
                      {costChangePercentage}% from last month
                    </span>
                  </>
                )}
                {trend === 'stable' && (
                  <>
                    <ArrowRight size={16} className="text-muted-foreground" />
                    <span className="text-muted-foreground">
                      Stable from last month
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={history}>
              <defs>
                <linearGradient id="costGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.45 0.15 250)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.45 0.15 250)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.85 0.01 240)" />
              <XAxis
                dataKey="date"
                stroke="oklch(0.45 0 0)"
                fontSize={12}
                tickLine={false}
                tickFormatter={(value) => {
                  const date = new Date(value)
                  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
                }}
                interval="preserveStartEnd"
                minTickGap={30}
              />
              <YAxis
                stroke="oklch(0.45 0 0)"
                fontSize={12}
                tickLine={false}
                tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-popover border border-border rounded-lg shadow-lg p-3">
                        <p className="text-sm text-muted-foreground mb-1">
                          {new Date(payload[0].payload.date).toLocaleDateString('en-US', {
                            month: 'long',
                            day: 'numeric',
                            year: 'numeric',
                          })}
                        </p>
                        <p className="text-lg font-bold">
                          {formatCurrency(payload[0].value as number)}
                        </p>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <Area
                type="monotone"
                dataKey="cost"
                stroke="oklch(0.45 0.15 250)"
                strokeWidth={2}
                fill="url(#costGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Top 10 Cost Drivers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Resource Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Resource Group</TableHead>
                  <TableHead className="text-right">Monthly Cost</TableHead>
                  <TableHead className="text-right">% of Total</TableHead>
                  <TableHead className="text-center">Trend</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topDrivers.map((driver, index) => (
                  <TableRow key={driver.resourceName}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground text-sm">#{index + 1}</span>
                        {driver.resourceName}
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {driver.resourceType}
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {driver.resourceGroup}
                    </TableCell>
                    <TableCell className="text-right font-semibold">
                      {formatCurrency(driver.cost)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge variant="outline">
                        {driver.percentageOfTotal.toFixed(1)}%
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      {driver.trend === 'up' && (
                        <TrendUp size={18} className="text-destructive mx-auto" />
                      )}
                      {driver.trend === 'down' && (
                        <TrendDown size={18} className="text-success mx-auto" />
                      )}
                      {driver.trend === 'stable' && (
                        <ArrowRight size={18} className="text-muted-foreground mx-auto" />
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleOpenPortal(driver.resourceName)}
                      >
                        <ArrowSquareOut size={16} className="mr-1" />
                        Portal
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
