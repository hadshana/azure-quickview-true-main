import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { CloudArrowDown, FileArrowDown, Envelope } from '@phosphor-icons/react'
import { toast } from 'sonner'
import type { AzureSubscription, DashboardFilter } from '@/lib/types'

interface DashboardHeaderProps {
  subscriptions: AzureSubscription[]
  selectedSubscription: string
  onSubscriptionChange: (subscriptionId: string) => void
  selectedFilters: DashboardFilter[]
  onFiltersChange: (filters: DashboardFilter[]) => void
  onGenerateReport: (format: 'pdf' | 'email') => void
}

interface UserInfo {
  login: string
  avatarUrl: string
  email?: string
}

const filterOptions: DashboardFilter[] = [
  'Untagged Virtual Machines',
  'Unattached Resources (VM, Disk, NIC, etc.)',
  'Azure Advisor Recommendations',
  'Patch Management Summary',
  'Runbook Schedule Overview',
  'Cost Analysis (last 3 months)',
  'Top 10 Cost Drivers',
]

export function DashboardHeader({
  subscriptions,
  selectedSubscription,
  onSubscriptionChange,
  selectedFilters,
  onFiltersChange,
  onGenerateReport,
}: DashboardHeaderProps) {
  const [user, setUser] = useState<UserInfo | null>(null)

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userInfo = await window.spark.user()
        setUser(userInfo)
      } catch (error) {
        console.error('Failed to load user:', error)
      }
    }
    loadUser()
  }, [])

  const handleFilterToggle = (filter: DashboardFilter) => {
    if (selectedFilters.includes(filter)) {
      onFiltersChange(selectedFilters.filter(f => f !== filter))
    } else {
      onFiltersChange([...selectedFilters, filter])
    }
  }

  return (
    <div className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Azure QuickView</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Comprehensive Azure resource monitoring and management
            </p>
          </div>
          <div className="flex items-center gap-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <CloudArrowDown size={18} />
                  Send Monthly Summary
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Export Options</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => onGenerateReport('pdf')}>
                  <FileArrowDown size={16} className="mr-2" />
                  Download PDF
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onGenerateReport('email')}>
                  <Envelope size={16} className="mr-2" />
                  Email Report
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {user && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={user.avatarUrl} alt={user.login} />
                      <AvatarFallback>
                        {user.login.substring(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.login}</p>
                      {user.email && (
                        <p className="text-xs leading-none text-muted-foreground">
                          {user.email}
                        </p>
                      )}
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem disabled>
                    <span className="text-xs text-muted-foreground">
                      Signed in via GitHub
                    </span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1">
            <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-1.5 block">
              Select Subscription
            </label>
            <Select value={selectedSubscription} onValueChange={onSubscriptionChange}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Choose a subscription" />
              </SelectTrigger>
              <SelectContent>
                {subscriptions.map(sub => (
                  <SelectItem key={sub.id} value={sub.id}>
                    {sub.displayName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex-1">
            <label className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-1.5 block">
              Dashboard Filters
            </label>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="w-full justify-between">
                  {selectedFilters.length === 0
                    ? 'All sections visible'
                    : `${selectedFilters.length} filter${selectedFilters.length > 1 ? 's' : ''} applied`}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel>Filter Dashboard Sections</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {filterOptions.map(filter => (
                  <DropdownMenuItem
                    key={filter}
                    onClick={(e) => {
                      e.preventDefault()
                      handleFilterToggle(filter)
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={selectedFilters.includes(filter)}
                      onChange={() => handleFilterToggle(filter)}
                      className="mr-2"
                    />
                    <span className="text-sm">{filter}</span>
                  </DropdownMenuItem>
                ))}
                {selectedFilters.length > 0 && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => onFiltersChange([])}>
                      Clear all filters
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </div>
  )
}
