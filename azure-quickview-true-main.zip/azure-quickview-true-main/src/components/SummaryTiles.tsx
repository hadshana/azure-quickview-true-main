import { Card, CardContent } from '@/components/ui/card'
import { HardDrives, Tag, Power, Stop } from '@phosphor-icons/react'
import { cn } from '@/lib/utils'

interface MetricTileProps {
  title: string
  value: number
  icon: React.ReactNode
  color: 'primary' | 'warning' | 'success' | 'muted'
  onClick?: () => void
}

const colorClasses = {
  primary: 'text-primary bg-primary/10',
  warning: 'text-warning bg-warning/10',
  success: 'text-success bg-success/10',
  muted: 'text-muted-foreground bg-muted',
}

export function MetricTile({ title, value, icon, color, onClick }: MetricTileProps) {
  return (
    <Card
      className={cn(
        'transition-all duration-200 hover:shadow-lg',
        onClick && 'cursor-pointer hover:scale-[1.02]'
      )}
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-sm font-medium text-muted-foreground uppercase tracking-wide mb-2">
              {title}
            </p>
            <p className="text-4xl font-bold tracking-tight">{value}</p>
          </div>
          <div className={cn('p-3 rounded-xl', colorClasses[color])}>{icon}</div>
        </div>
      </CardContent>
    </Card>
  )
}

interface SummaryTilesProps {
  totalVMs: number
  untaggedVMs: number
  runningVMs: number
  stoppedVMs: number
  onTileClick?: (section: string) => void
}

export function SummaryTiles({
  totalVMs,
  untaggedVMs,
  runningVMs,
  stoppedVMs,
  onTileClick,
}: SummaryTilesProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
      <MetricTile
        title="Total VMs"
        value={totalVMs}
        icon={<HardDrives size={28} weight="duotone" />}
        color="primary"
        onClick={() => onTileClick?.('all-vms')}
      />
      <MetricTile
        title="Untagged VMs"
        value={untaggedVMs}
        icon={<Tag size={28} weight="duotone" />}
        color="warning"
        onClick={() => onTileClick?.('untagged-vms')}
      />
      <MetricTile
        title="Running VMs"
        value={runningVMs}
        icon={<Power size={28} weight="duotone" />}
        color="success"
        onClick={() => onTileClick?.('running-vms')}
      />
      <MetricTile
        title="Stopped / Deallocated"
        value={stoppedVMs}
        icon={<Stop size={28} weight="duotone" />}
        color="muted"
        onClick={() => onTileClick?.('stopped-vms')}
      />
    </div>
  )
}
