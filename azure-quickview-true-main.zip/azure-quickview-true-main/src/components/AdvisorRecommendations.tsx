import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowSquareOut, Warning, ShieldCheck, ChartLine, Wrench } from '@phosphor-icons/react'
import type { AdvisorRecommendation } from '@/lib/types'
import { generateAzurePortalUrl } from '@/lib/helpers'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

interface AdvisorRecommendationsProps {
  recommendations: AdvisorRecommendation[]
}

const severityConfig = {
  Critical: {
    variant: 'destructive' as const,
    icon: <Warning size={16} weight="fill" />,
    className: 'bg-destructive text-destructive-foreground',
  },
  High: {
    variant: 'default' as const,
    icon: <Warning size={16} weight="fill" />,
    className: 'bg-warning text-warning-foreground',
  },
  Medium: {
    variant: 'secondary' as const,
    icon: <Warning size={16} />,
    className: 'bg-info text-info-foreground',
  },
  Low: {
    variant: 'outline' as const,
    icon: <Warning size={16} />,
    className: '',
  },
}

const categoryIcons = {
  Security: <ShieldCheck size={16} weight="duotone" />,
  Cost: <ChartLine size={16} weight="duotone" />,
  Performance: <ChartLine size={16} weight="duotone" />,
  Reliability: <ShieldCheck size={16} weight="duotone" />,
  'Operational Excellence': <Wrench size={16} weight="duotone" />,
}

export function AdvisorRecommendations({ recommendations }: AdvisorRecommendationsProps) {
  const handleOpenPortal = (recommendation: AdvisorRecommendation) => {
    const url = generateAzurePortalUrl(recommendation.impactedResource)
    window.open(url, '_blank', 'noopener,noreferrer')
    toast.success(`Opening recommendation in Azure Portal`)
  }

  const handleRemediate = (recommendation: AdvisorRecommendation) => {
    toast.success(`Remediation initiated for ${recommendation.vmName}`, {
      description: recommendation.title,
    })
  }

  const criticalCount = recommendations.filter(r => r.severity === 'Critical').length
  const highCount = recommendations.filter(r => r.severity === 'High').length

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Azure Advisor Recommendations</CardTitle>
          <div className="flex gap-2">
            {criticalCount > 0 && (
              <Badge variant="destructive" className="gap-1">
                <Warning size={14} weight="fill" />
                {criticalCount} Critical
              </Badge>
            )}
            {highCount > 0 && (
              <Badge className="gap-1 bg-warning text-warning-foreground">
                <Warning size={14} weight="fill" />
                {highCount} High
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Severity</TableHead>
                <TableHead>VM Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Recommendation</TableHead>
                <TableHead>Resource Group</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recommendations.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                    No recommendations available. Your resources are optimized!
                  </TableCell>
                </TableRow>
              ) : (
                recommendations
                  .sort((a, b) => {
                    const severityOrder = { Critical: 0, High: 1, Medium: 2, Low: 3 }
                    return severityOrder[a.severity] - severityOrder[b.severity]
                  })
                  .map(rec => {
                    const config = severityConfig[rec.severity]
                    return (
                      <TableRow key={rec.id} className={rec.severity === 'Critical' ? 'bg-destructive/5' : ''}>
                        <TableCell>
                          <Badge variant={config.variant} className={cn('gap-1', config.className)}>
                            {config.icon}
                            {rec.severity}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">{rec.vmName}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-muted-foreground">
                            {categoryIcons[rec.category]}
                            <span className="text-sm">{rec.category}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{rec.title}</div>
                            <div className="text-sm text-muted-foreground mt-1">
                              {rec.description}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {rec.resourceGroup}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex gap-2 justify-end">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenPortal(rec)}
                            >
                              <ArrowSquareOut size={16} className="mr-1" />
                              Portal
                            </Button>
                            <Button
                              variant="default"
                              size="sm"
                              onClick={() => handleRemediate(rec)}
                            >
                              <Wrench size={16} className="mr-1" />
                              Fix
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
